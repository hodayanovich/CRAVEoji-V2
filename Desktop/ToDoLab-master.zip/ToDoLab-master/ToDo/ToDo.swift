//
//  ToDo.swift
//  ToDo
//
//  Created by Sofia Ongele on 5/23/19.
//  Copyright © 2019 Sofia Ongele. All rights reserved.
//

import UIKit

class ToDo {
    var name = ""
    var important = false
}
